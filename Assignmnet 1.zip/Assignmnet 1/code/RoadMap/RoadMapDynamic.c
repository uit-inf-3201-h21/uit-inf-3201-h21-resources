#include <stdio.h>
#include <math.h>
// #include "complex_lib.h"
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <mpi.h>

#define WIDTH 1000
#define HEIGHT 1000

// The maximum number of iterations we will compute before giving up at a given coordinate
// This used to be 1024, but that masked out all the variation between 1-100, where most of the details are. 
#define MAX_ITERATIONS 100

#define RESULT 0    // MPI TAG forsending results to master
#define WORK 1      // MPI TAG for sending work to slaves
#define POISON 2    // MPI TAG to kill slaves

int DO_DUMP = 0;    // true if we want to dump the iterations from the file
int zooms = 10;     // number of zooms before we stop
int crc = 0;        // used for debugging (compare parallel with sequential, for instance)
int size;           // Size of COMM_WORLD
int rank;           // Rank of process / process id

int road_map[HEIGHT][WIDTH];

double box_x_min, box_x_max, box_y_min, box_y_max;


// ###### complex_lib.h content ######
//
// Had problems with linking when using scorep - put this here insted to fix it

typedef struct complex {
    double real;
    double imag;
} complex; 

complex complex_squared(complex c1) {
    complex c = {
        c1.real * c1.real - c1.imag * c1.imag, 
        2 * c1.real * c1.imag
    }; 
    return c; 
}

complex complex_add(complex a, complex b) {
    complex c; 
    c.real = a.real + b.real;
    c.imag = a.imag + b.imag;
    return c; 
}

// Returns magnitude squared (saves a square root operation)
float complex_magn2(complex c) {
    return c.real * c.real + c.imag * c.imag; 
}

// #################################


long long get_usecs()
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec * 1000000LL + tv.tv_usec; 
}

/** 
 * Dumping the roadMap array for later visualization. 
 */
void dump_data()
{
    char fname[256];
    FILE *fp;
    static int filenum = 0; 
    if (!DO_DUMP)
        return;
    
    /* Stores the data as a Python datastructure for easy inspection and plotting */ 
    sprintf(fname, "data/roadmap-dyn-out-%04d.data", filenum++);
    printf("Storing data to %s.\n", fname); 
    fp = fopen(fname, "w");
    fprintf(fp, "{\n"); 
    fprintf(fp, "  'expdata' : 'roadmap-dyn',\n"); 
    fprintf(fp, "  'arr'     : [\n"); 
    for (int y = 0; y < HEIGHT; y++) {
        fprintf(fp, "     [ "); 
        for (int x = 0; x < WIDTH; x++) {
            fprintf(fp, "%d, ", road_map[y][x]);
        }
        fprintf(fp, "],\n"); 
    }
    fprintf(fp, "], \n"); 
    fprintf(fp, "} \n");
    fclose(fp); 
}


/**
 * Translate from pixel coordinates to space coordinates
 * 
 * @param       x       Pixel coordinate
 * @returns     Space coordinate
 */
double translate_x(int x) {       
    return box_x_min + (((box_x_max-box_x_min)/WIDTH)*x);
}

/**
 * Translate from pixel coordinates to space coordinates
 * 
 * @param       y       Pixel coordinate
 * @returns     Space coordinate
 */
double translate_y(int y) {
    return box_y_min + (((box_y_max-box_y_min)/HEIGHT)*y);
}

/**
 * Mandelbrot divergence test
 * 
 * @param       x,y     Space coordinates
 * @returns     Number of iterations before convergance
 */
int solve(double x, double y)
{
    complex z = {0.0, 0.0};
    complex c = {x, y};
    int itt = 0;
    for (itt = 0; (itt < MAX_ITERATIONS) && (complex_magn2(z) <= 4.0); itt++) {
        z = complex_add(complex_squared(z), c); 
    }
    return itt;
}

// adds received rows from slaves to road_map. used by the master process
void addResults(int y, int results[]) {
    for(int x = 0; x < WIDTH; x++) {
        road_map[y][x] = results[x];
        crc += results[x];
    }
}

// function that the master process executes to assign tasks until the workload is done
void master() {
    int count = 0;          // # of tasks sent out and need to wait for respons from
    int row = 0;            // how far through the workload we are
    int current_row[size];  // list to keep track of which row which slave is working on
    int response[WIDTH];    // buffer to keep incoming computed rows
    MPI_Status status;      // status of latest message received

    if (DO_DUMP)
        printf("xmin %.4f xmax %.4f ymin %.4f ymax %.4f\n", box_x_min, box_x_max, box_y_min, box_y_max);
    
    // Send out initial work (1 row to each worker)
    for (int p = 1; p < size; p++) {
        MPI_Send(&row, 1, MPI_INT, p, WORK, MPI_COMM_WORLD);
        current_row[p] = row;
        count++;
        row++;
    }

    // Receive all tasks and send out new ones as long as there are rows left
    do {
        // wait for calculated row from slave
        MPI_Recv(response, WIDTH, MPI_INT, MPI_ANY_SOURCE, RESULT, MPI_COMM_WORLD, &status);
        count--;
        if (row < HEIGHT) {
            // Send out new task as long as there are rows
            MPI_Send(&row, 1, MPI_INT, status.MPI_SOURCE, WORK, MPI_COMM_WORLD);
            current_row[status.MPI_SOURCE] = row; // keep track of which row is sent to which slave
            row++;
            count++;
        } else {
            // No more rows to calculate - kill the slave
            MPI_Send(&row, 1, MPI_INT, status.MPI_SOURCE, POISON, MPI_COMM_WORLD);
        }
        // Add results to road_map after sending out new row to slave
        addResults(current_row[status.MPI_SOURCE], response);
    } while (count > 0);
    dump_data();
}


// function executed by slave to receive work from master
void slave() {
    MPI_Status status;      // status of latest message
    int response[WIDTH];    // buffer for response
    int row;                // current row to calculate

    // receive initial task
    MPI_Recv(&row, 1, MPI_INT, 0, MPI_ANY_TAG, MPI_COMM_WORLD, &status);

    // While incoming messages contain tasks - calculate the row asked for
    while(status.MPI_TAG != POISON) {
        for(int x = 0; x < WIDTH; x++) {
            response[x] = solve(translate_x(x), translate_y(row));
        }
        // Send result and wait for new task or poison
        MPI_Send(response, WIDTH, MPI_INT, 0, RESULT, MPI_COMM_WORLD);
        MPI_Recv(&row, 1, MPI_INT, 0, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
    }
}

/**
 * Sets up the coordinate space and generates the map at different zoom level
 * 
 */
void roadMap ()
{
    // Sets the bounding box, 
    box_x_min = -1.5; box_x_max = 0.5;
    box_y_min = -1.0; box_y_max = 1.0;

    double deltaxmin = (-0.90 - box_x_min) / zooms;
    double deltaxmax = (-0.65 - box_x_max) / zooms;
    double deltaymin = (-0.40 - box_y_min) / zooms;
    double deltaymax = (-0.10 - box_y_max) / zooms;

    // Updates the map for every zoom level
    if (rank == 0) {
        master();
    } else {
        slave();
    }
    for (int i = 0; i < zooms; i++) {
        box_x_min += deltaxmin;
        box_x_max += deltaxmax;
        box_y_min += deltaymin;
        box_y_max += deltaymax;
        if (rank == 0) {
            master();
        } else {
            slave();
        }
    }                       
}

int main (int argc, char *argv[])
{
    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &size); 
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    switch(argc) {
    case 2:
        if (strcmp("dump", argv[1]) == 0) {
            DO_DUMP = 1; 
        }
    }

    long long t1 = get_usecs(); 
    roadMap();
    long long t2 = get_usecs();

    if(rank == 0){
        printf("{'name' : 'roadmap_dyn', 'usecs' : %lld, 'secs' : %f, 'width' : %d, 'height' : %d, 'CRC' : 0x%x}\n", 
           t2-t1, (t2-t1)/1000000.0, WIDTH, HEIGHT, crc);
    }
    
    MPI_Finalize();
    return 0;
}
