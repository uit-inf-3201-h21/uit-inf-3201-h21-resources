#include <stdio.h>
#include <math.h>
// #include "complex_lib.h"
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <mpi.h>

#define WIDTH 2000
#define HEIGHT 2000

// The maximum number of iterations we will compute before giving up at a given coordinate
// This used to be 1024, but that masked out all the variation between 1-100, where most of the details are. 
#define MAX_ITERATIONS 100

#define WORK 1      // MPI TAG for work messages from amster to slave

int DO_DUMP = 0;    // true if we want to dump the iterations from the file
int zooms = 10;     // number of zooms before we stop
int crc = 0;        // used for debugging (compare parallel with sequential, for instance)
int size;           // Size of COMM_WORLD
int rank;           // rank of process
int strip_height;   // height of strip (rows per task)
int max_height;     // last strip may contain more rows

int road_map[HEIGHT][WIDTH];

double box_x_min, box_x_max, box_y_min, box_y_max;

// ###### complex_lib.h content ######
//
// Had problems with linking when using scorep - put this here insted to fix it
typedef struct complex {
    double real;
    double imag;
} complex; 

complex complex_squared(complex c1) {
    complex c = {
        c1.real * c1.real - c1.imag * c1.imag, 
        2 * c1.real * c1.imag
    }; 
    return c; 
}

complex complex_add(complex a, complex b) {
    complex c; 
    c.real = a.real + b.real;
    c.imag = a.imag + b.imag;
    return c; 
}

// Returns magnitude squared (saves a square root operation)
float complex_magn2(complex c) {
    return c.real * c.real + c.imag * c.imag; 
}

// #################################


long long get_usecs()
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec * 1000000LL + tv.tv_usec; 
}

/** 
 * Dumping the roadMap array for later visualization. 
 */
void dump_data()
{
    char fname[256];
    FILE *fp;
    static int filenum = 0; 
    if (!DO_DUMP)
        return;
    
    /* Stores the data as a Python datastructure for easy inspection and plotting */ 
    sprintf(fname, "data/roadmap-stat-out-%04d.data", filenum++);
    printf("Storing data to %s.\n", fname); 
    fp = fopen(fname, "w");
    fprintf(fp, "{\n"); 
    fprintf(fp, "  'expdata' : 'roadmap-stat',\n"); 
    fprintf(fp, "  'arr'     : [\n"); 
    for (int y = 0; y < HEIGHT; y++) {
        fprintf(fp, "     [ "); 
        for (int x = 0; x < WIDTH; x++) {
            fprintf(fp, "%d, ", road_map[y][x]);
        }
        fprintf(fp, "],\n"); 
    }
    fprintf(fp, "], \n"); 
    fprintf(fp, "} \n");
    fclose(fp); 
}


/**
 * Translate from pixel coordinates to space coordinates
 * 
 * @param       x       Pixel coordinate
 * @returns     Space coordinate
 */
double translate_x(int x) {       
    return box_x_min + (((box_x_max-box_x_min)/WIDTH)*x);
}

/**
 * Translate from pixel coordinates to space coordinates
 * 
 * @param       y       Pixel coordinate
 * @returns     Space coordinate
 */
double translate_y(int y) {
    return box_y_min + (((box_y_max-box_y_min)/HEIGHT)*y);
}

/**
 * Mandelbrot divergence test
 * 
 * @param       x,y     Space coordinates
 * @returns     Number of iterations before convergance
 */
int solve(double x, double y)
{
    complex z = {0.0, 0.0};
    complex c = {x, y};
    int itt = 0;
    for (itt = 0; (itt < MAX_ITERATIONS) && (complex_magn2(z) <= 4.0); itt++) {
        z = complex_add(complex_squared(z), c); 
    }
    return itt;
}

// Adds received rows from slaves to road_map. Used by the master process
void addResults(int y, int results[]) {
    for(int x = 0; x < WIDTH; x++) {
        road_map[y][x] = results[x];
        crc += results[x];
    }
}

// optimization where master also does work
void calcRow(int y) {
    int row[WIDTH];
    for (int x=0; x<WIDTH; x++) {
        int c = solve(translate_x(x), translate_y(y));
        row[x] = c;
    }
    addResults(y, row);
}

// function that the master process executes to assign tasks until the workload is done
void master() {
    int pid = 1;          // rank of process to send task to
    int response[WIDTH];  // buffer to keep incoming computed rows
    MPI_Status status;    // status of latest message - used to know which row was received from the tag

    int self_i = 0;

    if (DO_DUMP)
        printf("xmin %.4f xmax %.4f ymin %.4f ymax %.4f\n", box_x_min, box_x_max, box_y_min, box_y_max);
    
    // Send out work using strip partitioning
    int y_max = HEIGHT - (HEIGHT % size);
    for (int y = strip_height; y < y_max; y += strip_height) {
        MPI_Send(&y, 1, MPI_INT, pid, WORK, MPI_COMM_WORLD);
        pid++;
    }

    // Collect results
    for (int i = strip_height; i < HEIGHT; i++) {
        MPI_Recv(response, WIDTH, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
        addResults(status.MPI_TAG, response); // Tag is used to know which row was received
        
        // master also does some work
        if (self_i < strip_height) {
            calcRow(self_i);
            self_i++;
        }
    }

    dump_data();
}

// function executed by slave to receive work from master
void slave() {
    int response[WIDTH];        // buffer to hold computed row for sending
    int y_0;                    // first row of task
    int y_max = strip_height;   // last row of task
    if(rank == size-1) {          // last row might be a bit larger
        y_max = max_height;
    }
    
    // receive task
    MPI_Recv(&y_0, 1, MPI_INT, 0, WORK, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

    // solve task
    for (int i = 0; i < y_max; i++) {
        for (int x=0; x<WIDTH; x++) {
            int c = solve(translate_x(x), translate_y(y_0 + i));
            response[x] = c;
        }
        // send each row instead of waiting till all are finished
        MPI_Send(response, WIDTH, MPI_INT, 0, y_0 + i, MPI_COMM_WORLD);
    }
}

/**
 * Sets up the coordinate space and generates the map at different zoom level
 * 
 */
void roadMap ()
{
    // Sets the bounding box, 
    box_x_min = -1.5; box_x_max = 0.5;
    box_y_min = -1.0; box_y_max = 1.0;

    double deltaxmin = (-0.90 - box_x_min) / zooms;
    double deltaxmax = (-0.65 - box_x_max) / zooms;
    double deltaymin = (-0.40 - box_y_min) / zooms;
    double deltaymax = (-0.10 - box_y_max) / zooms;

    // Updates the map for every zoom level
    if (rank == 0) {
        master();
    } else {
        slave();
    }
    for (int i = 0; i < zooms; i++) {
        box_x_min += deltaxmin;
        box_x_max += deltaxmax;
        box_y_min += deltaymin;
        box_y_max += deltaymax;
        if (rank == 0) {
            master();
        } else {
            slave();
        }
    }                       
}

int main (int argc, char *argv[])
{
    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &size); 
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    size = size;

    switch(argc) {
    case 2:
        if (strcmp("dump", argv[1]) == 0) {
            DO_DUMP = 1; 
        }
    }

    strip_height = (HEIGHT - (HEIGHT % size)) / size;  // height of tasks
    max_height = strip_height + (HEIGHT % size);       // last task might have a taller strip

    long long t1 = get_usecs(); 
    roadMap();
    long long t2 = get_usecs(); 

    if(rank == 0){
        printf("{'name' : 'roadmap_stat', 'usecs' : %lld, 'secs' : %f, 'width' : %d, 'height' : %d, 'CRC' : 0x%x}\n", 
           t2-t1, (t2-t1)/1000000.0, WIDTH, HEIGHT, crc);
    }
    
    MPI_Finalize();
    return 0;
}
