Output directory for roadmap data
