#!/bin/bash -l

if [ $# -lt 3 ]
  then
    echo "Usage: static|dynamic num_procs num_hosts"
    exit
fi

sh generate_hosts.sh $3

# You need to create these files (RoadMapStatic & RoadMapDynamic) first - Makefile!
if [ "$1" = "static" ]; then
  mpirun -np $2 -hostfile hostfile RoadMapStatic
elif [ "$1" = "dynamic" ]; then
  mpirun -np $2 -hostfile hostfile RoadMapDynamic
fi

